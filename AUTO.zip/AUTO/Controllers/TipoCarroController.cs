﻿using AUTO.Models;
using AUTO.Servicios;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AUTO.Controllers
{
    public class TipoCarroController : Controller
    {
        private readonly IRepositorioTipoCarro repositorioTipoCarro;

        //IMPORT O USING
        public TipoCarroController(IRepositorioTipoCarro repositorioTipoCarro)
        {
            this.repositorioTipoCarro = repositorioTipoCarro;
        }

        //SERVICIO CONFIGURADO

        public async Task<IActionResult> Index()
        {
            var tipoCarro = await repositorioTipoCarro.obtener();
            return View(tipoCarro);
        }

        public IActionResult crear()
        {
            return View();
        }

        [HttpPost]

        public async Task<IActionResult> Crear(TipoCarroViewModel tipoCarro)
        {
            if (!ModelState.IsValid)
            {
                return View(tipoCarro);
            }
            await repositorioTipoCarro.crear(tipoCarro);
            return RedirectToAction("Index");

        }

        [HttpGet]

        public async Task<IActionResult> Editar(int id)
        {
            var tipoCarro = await repositorioTipoCarro.obtenerPorId(id);

            if (tipoCarro is null)
            {
                return RedirectToAction("No Encontrado", "Home");
            }
            return View(tipoCarro);
        }

        [HttpPost]

        public async Task<IActionResult> Editar(TipoCarroViewModel tipoCarro)
        {
            var tipoCarroExiste = await repositorioTipoCarro.obtenerPorId(tipoCarro.GSId_auto);

            if (tipoCarroExiste is null)
            {
                return RedirectToAction("No encontrado", "Home");
            }
            await repositorioTipoCarro.actualizar(tipoCarro);
            return RedirectToAction("Index");
        }


        [HttpGet]
        public async Task<IActionResult> Borrar(int id)
        {

            var tipoCarro = await repositorioTipoCarro.obtenerPorId(id);

            if(tipoCarro is null)
            {
                return RedirectToAction("No encontrado", "Home");
            }
            return View(tipoCarro);
        }


        [HttpPost]

        public async Task<IActionResult> BorrarTipoCarro(TipoCarroViewModel tipoCarro)
        {
            var tipoCarroExiste = await repositorioTipoCarro.obtenerPorId(tipoCarro.GSId_auto);

            if(tipoCarroExiste is null)
            {
                return RedirectToAction("No encontrado", "Home");
            }
            await repositorioTipoCarro.Borrar(tipoCarro.GSId_auto);

            return RedirectToAction("Index");
        }
    }
}
