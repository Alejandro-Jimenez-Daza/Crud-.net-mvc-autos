﻿namespace AUTO.Models
{
    public class TipoCarroViewModel
    {
        //GS: GET Y SET
        public int GSId_auto { get; set; }
        public string GSMarca { get; set; }
        public string GSModelo { get; set; }
        public int GSAño { get; set; }
        public string GSColor { get; set; }
    }
}
