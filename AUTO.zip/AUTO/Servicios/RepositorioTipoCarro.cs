﻿using Dapper;
using Microsoft.Data.SqlClient;
using AUTO.Models;

namespace AUTO.Servicios
{
    public interface IRepositorioTipoCarro
    {
        Task actualizar(TipoCarroViewModel tipoCarro);
        Task Borrar(int id_auto);
        Task crear (TipoCarroViewModel tipoCarro);
        Task<IEnumerable<TipoCarroViewModel>> obtener();
        Task<TipoCarroViewModel> obtenerPorId(int id_auto);
    }



    public class RepositorioTipoCarro : IRepositorioTipoCarro
    {
        private readonly string connectionString;
        //IConfiguration ES: para llamar las configuraciones de modo interno las configuraciones de .json

        public RepositorioTipoCarro(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        //FUNCIONES ASINCRONAS SON MÁS RAPIDAS
        public async Task<IEnumerable<TipoCarroViewModel>> obtener()
        {
            using var connection = new SqlConnection(connectionString);
			//AWAIT -> ESPERAR INFORMACION DE BASE DE DATOS (PROMESAS)
			return await connection.QueryAsync<TipoCarroViewModel>(
                @"SELECT id_auto as GSId_auto, marca as GSMarca, modelo as GSModelo, año as GSAño, color as GSColor
                FROM tbl_autos");
        }

        public async Task crear(TipoCarroViewModel tipoCarro)
        {
            using var connection = new SqlConnection(connectionString);
            await connection.QueryAsync("SP_GUARDAR_AUTO",
                                                            new { marca = tipoCarro.GSMarca,
                                                                modelo = tipoCarro.GSModelo,
                                                                año = tipoCarro.GSAño,
                                                                color = tipoCarro.GSColor },
                                                            commandType: System.Data.CommandType.StoredProcedure);
        }

        public async Task actualizar(TipoCarroViewModel tipoCarro)
        {
            using var connection = new SqlConnection(connectionString);
            await connection.ExecuteAsync(@"UPDATE tbl_autos
                                            SET marca= @GSMarca,
                                                modelo = @GSModelo,
                                                año = @GSAño,
                                                color = @GSColor
                                                WHERE id_auto = @GSId_auto", tipoCarro);
        }

        public async Task<TipoCarroViewModel> obtenerPorId(int id_auto)
        {
            using var connection = new SqlConnection(connectionString);
            //AWAIT -> ESPERAR INFORMACION DE BASE DE DATOS (PROMESAS)
            return await connection.QueryFirstOrDefaultAsync<TipoCarroViewModel>(
                @"SELECT id_auto as GSId_auto, marca as GSMarca, modelo as GSModelo, año as GSAño, color as GSColor
                FROM tbl_autos
                WHERE id_auto=@id_auto;", new { id_auto });

        }

        public async Task Borrar(int id_auto)
        {
            using var connection = new SqlConnection(connectionString);
            await connection.ExecuteAsync(@"DELETE tbl_autos
                                            WHERE id_auto=@id_auto;", new { id_auto });
        }
    }
}
